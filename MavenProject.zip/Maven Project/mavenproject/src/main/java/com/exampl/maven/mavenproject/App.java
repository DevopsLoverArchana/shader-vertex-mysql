package com.exampl.maven.mavenproject;

/**
 * Hello world!
 */
public class App {

    private static final String MESSAGE = "My First Maven Project ";

    public App() {}

    public static void main(String[] args) {
        System.out.println(MESSAGE);
    }

    public String getMessage() {
        return MESSAGE;
    }
}